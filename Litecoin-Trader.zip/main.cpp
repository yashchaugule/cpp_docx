#include <iostream>
#include <stdio.h>
#include <string>

int main() {

int next;
int walletLtc = 0;
int walletUsdt = 2500;
int buy;
int sell;
int increase;

std::string userName;

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "Hello! Are you ready to trade cryptocurrency?" << std::endl;
std::cout << "Input your name " << std::endl;
std::cin >> userName;

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "Nice to meet you " << userName << "," << std::endl;
std::cout << "i'am AI which will help you to trade cryptocurrency." << std::endl;
std::cout << "We have 1 week to increase your deposit - 2500 USD₮" << std::endl;
std::cout << "USD₮ is stablecoin called Tether and 1 USD₮ always equal 1 USD" << std::endl;
std::cout << std::endl;
std::cout << "(0 and enter for continue)" << std::endl;
std::cin >> next;

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Monday" << std::endl;
std::cout << "▓▒░ Days left: 6" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 180 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc = buy / 180;
    walletUsdt -= buy; 
  } else if (next != 2) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Tuesday" << std::endl;
std::cout << "▓▒░ Days left: 5" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 160 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - sell litecoin" <<std::endl;
std::cout << "3 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc += buy / 160;
    walletUsdt -= buy;
  } else if (next == 2) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of ŁTC you want to sell: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> sell;
    walletLtc -= sell;
    walletUsdt += sell * 160;   
  } else if (next != 3) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Wednesday" << std::endl;
std::cout << "▓▒░ Days left: 4" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 190 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - sell litecoin" <<std::endl;
std::cout << "3 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc += buy / 190;
    walletUsdt -= buy;
  } else if (next == 2) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of ŁTC you want to sell: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> sell;
    walletLtc -= sell;
    walletUsdt += sell * 190;   
  } else if (next != 3) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Thursday" << std::endl;
std::cout << "▓▒░ Days left: 3" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 130 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - sell litecoin" <<std::endl;
std::cout << "3 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc += buy / 130;
    walletUsdt -= buy;
  } else if (next == 2) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of ŁTC you want to sell: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> sell;
    walletLtc -= sell;
    walletUsdt += sell * 130;   
  } else if (next != 3) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Friday" << std::endl;
std::cout << "▓▒░ Days left: 2" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 120 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - sell litecoin" <<std::endl;
std::cout << "3 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc += buy / 120;
    walletUsdt -= buy;
  } else if (next == 2) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of ŁTC you want to sell: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> sell;
    walletLtc -= sell;
    walletUsdt += sell * 120;   
  } else if (next != 3) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Saturday" << std::endl;
std::cout << "▓▒░ Days left: 1" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 150 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - sell litecoin" <<std::endl;
std::cout << "3 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc += buy / 150;
    walletUsdt -= buy;
  } else if (next == 2) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of ŁTC you want to sell: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> sell;
    walletLtc -= sell;
    walletUsdt += sell * 150;   
  } else if (next != 3) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Today is: Saturday" << std::endl;
std::cout << "▓▒░ Days left: 0" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
std::cout << "Litecoin price today (ŁTC / USD₮):" << std::endl;
std::cout << "1 Ł = 190 $" << std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cout << "1 - buy litecoin" <<std::endl;
std::cout << "2 - sell litecoin" <<std::endl;
std::cout << "3 - skip this day" <<std::endl;
std::cout << "―――――――――――――――――――" << std::endl;
std::cin >> next;

  if (next == 1) {
    std::cout << "Enter the amount of USD₮ for buying ŁTC: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> buy;
    walletLtc += buy / 190;
    walletUsdt -= buy;
  } else if (next == 2) {
    std::cout << "―――――――――――――――――――" << std::endl;
    std::cout << "Enter the amount of ŁTC you want to sell: " << std::endl;
    std::cout << "(Cryptocurrency exchange requirement: please use only integers!)" << std::endl;
    std::cin >> sell;
    walletLtc -= sell;
    walletUsdt += sell * 190;   
  } else if (next != 3) {
    std::cout << "ERROR! BE CAREFUL! GAME OVER!!!" << std::endl;
    exit(0);
  }

system("clear");
std::cout << "―――――――――――――――― Litecoin Trader Mini Game v.1.2 ――――――――――――――――" << std::endl; std::cout << std::endl; std::cout << std::endl; std::cout << std::endl;
std::cout << std::endl;
std::cout << "▓▒░ Your trading week is finished!" << std::endl;
std::cout << "▓▒░ (Your tether balance: " << walletUsdt << " USD₮)" << std::endl;
std::cout << "▓▒░ (Your litecoin balance: " << walletLtc << " ŁTC)" << std::endl;
std::cout << std::endl;std::cout << std::endl;std::cout << std::endl;
std::cout << std::endl;
  if (walletLtc != 0) {
    std::cout << "Whoops! You dont sell all your litecoins!" << std::endl;
    std::cout << "Your trading mission failed" << std::endl;
    std::cout << "Please try again, " << userName << std::endl;
    exit(0);
  } else if (walletUsdt <= 2500) {
    std::cout << "Hey, " << userName << "!" << std::endl;
    std::cout << "You couldn't increase your deposit." << std::endl;
    std::cout << "Please try again!" << std::endl;
  } else if (walletUsdt > 2500) {
    std::cout << "Good job, " << userName << "!" << std::endl;
    std::cout << "You increase your deposit on " << walletUsdt - 2500 << " USD₮" << std::endl;
    std::cout << "What equal " << walletUsdt - 2500 << " United States Dollars!" << std::endl; std::cout << std::endl;
  }
}
